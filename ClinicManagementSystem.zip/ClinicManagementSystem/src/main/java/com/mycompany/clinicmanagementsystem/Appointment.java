
package com.mycompany.clinicmanagementsystem;

public class Appointment {
    private String timeSlot;
    private String patientId;
    private AppointmentStatus status;
    private String doctorName;

    public Appointment(String timeSlot, String patientId, AppointmentStatus status, String doctorName) {
        this.timeSlot = timeSlot;
        this.patientId = patientId;
        this.status = status;
        this.doctorName = doctorName;
    }
    public String getTimeSlot(){return timeSlot;}
    public String getPatientId(){return patientId;}
    public AppointmentStatus getStatus(){return status;}
    public void setPatientId(String v){patientId=v;}
    public void setStatus(AppointmentStatus v){status=v;}
    public void displayDetails() {
        System.out.println(timeSlot + " | Doctor: " + doctorName + " | Status: " + status + (patientId!=null?" | Patient: "+patientId:""));
    }
}