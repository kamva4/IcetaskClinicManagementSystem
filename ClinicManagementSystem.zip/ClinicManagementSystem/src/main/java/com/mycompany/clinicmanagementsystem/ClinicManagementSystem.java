
package com.mycompany.clinicmanagementsystem;

import java.util.*;

public class ClinicManagementSystem {
    private static final String[] DAYS = {"Monday", "Tuesday", "Wednesday"};
    private static final String[] TIMES = {"9:00 AM", "10:00 AM", "11:00 AM", "2:00 PM", "3:00 PM"};

    private List<Patient> patients;
    private List<Appointment> appointments;
    private Map<String, String> patientAppointmentMap;

    public ClinicManagementSystem() {
        patients = new ArrayList<>();
        appointments = new ArrayList<>();
        patientAppointmentMap = new HashMap<>();
        initializeAppointments();
    }

    private void initializeAppointments() {
        for (String day : DAYS) {
            for (String time : TIMES) {
                appointments.add(new Appointment(day + " " + time, null, AppointmentStatus.AVAILABLE, "Dr. Smith"));
            }
        }
    }

    public boolean addPatient(Patient p) {
        if (searchPatient(p.getPatientId()) != null) return false;
        patients.add(p);
        return true;
    }

    public Patient searchPatient(String id) {
        for (Patient p : patients) if (p.getPatientId().equalsIgnoreCase(id)) return p;
        return null;
    }

    public boolean scheduleAppointment(String timeSlot, String patientId) {
        Patient p = searchPatient(patientId);
        if (p == null) return false;
        if (p.getPatientType() != PatientType.GENERAL) return false;
        if (patientAppointmentMap.containsKey(patientId.toUpperCase())) return false;
        for (Appointment a : appointments) {
            if (a.getTimeSlot().equalsIgnoreCase(timeSlot)) {
                if (a.getStatus() != AppointmentStatus.AVAILABLE) return false;
                a.setPatientId(patientId.toUpperCase());
                a.setStatus(AppointmentStatus.BOOKED);
                patientAppointmentMap.put(patientId.toUpperCase(), timeSlot);
                return true;
            }
        }
        return false;
    }

    public List<Appointment> getAppointments() { return appointments; }
    public List<Patient> getPatients() { return patients; }

    // THIS IS WHAT WAS MISSING - causing your red lines
    public List<Patient> sortBySurname() {
        List<Patient> copy = new ArrayList<>(patients);
        copy.sort(Comparator.comparing(Patient::getLastName));
        return copy;
    }
    
    public List<Patient> sortByPatientId() {
        List<Patient> copy = new ArrayList<>(patients);
        copy.sort(Comparator.comparing(Patient::getPatientId));
        return copy;
    }
}