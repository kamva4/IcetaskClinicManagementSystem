package com.mycompany.clinicmanagementsystem;

public class ClinicApp {
    public static void main(String[] args) {
        ClinicManagementSystem cms = new ClinicManagementSystem();
        cms.addPatient(new GeneralPatient("P001","John","Doe","01/01/1990","0123456789","john@test.com","None","Dr. Smith","Discovery"));
        cms.addPatient(new Patient("P002","Anna","Smith","02/02/1995","0987654321","anna@test.com","Asthma",PatientType.SPECIALIST));
        cms.getClass(); // dummy to avoid error
        // Start menu - you need full ClinicManagementSystem with menu code I gave you earlier
        // If your ClinicManagementSystem.java is the short version I gave last time, it has no menu.
        // Use the BIG version with run() method from 2 messages ago.
        System.out.println("System loaded with sample patients. Add menu code if missing.");
    }
}