/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.clinicmanagementsystem;

/**
 *
 * @author USER
 */
public class Patient {
    private String patientId;
    private String firstName;
    private String lastName;
    private String dateOfBirth;
    private String contactNumber;
    private String email;
    private String medicalHistory;
    private PatientType patientType;

    public Patient(String patientId, String firstName, String lastName, String dateOfBirth,
                   String contactNumber, String email, String medicalHistory, PatientType patientType) {
        this.patientId = patientId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.contactNumber = contactNumber;
        this.email = email;
        this.medicalHistory = medicalHistory;
        this.patientType = patientType;
    }
    public String getPatientId() { return patientId; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getDateOfBirth() { return dateOfBirth; }
    public String getContactNumber() { return contactNumber; }
    public String getEmail() { return email; }
    public String getMedicalHistory() { return medicalHistory; }
    public PatientType getPatientType() { return patientType; }

    public void setFirstName(String v){this.firstName=v;}
    public void setLastName(String v){this.lastName=v;}
    public void setDateOfBirth(String v){this.dateOfBirth=v;}
    public void setContactNumber(String v){this.contactNumber=v;}
    public void setEmail(String v){this.email=v;}
    public void setMedicalHistory(String v){this.medicalHistory=v;}
    public void setPatientType(PatientType v){this.patientType=v;}

    public void displayDetails() {
        System.out.println("-----------------------------------");
        System.out.println("Patient ID: " + patientId);
        System.out.println("Name: " + firstName + " " + lastName);
        System.out.println("DOB: " + dateOfBirth + " | Contact: " + contactNumber);
        System.out.println("Email: " + email);
        System.out.println("Medical History: " + medicalHistory);
        System.out.println("Type: " + patientType);
        System.out.println("-----------------------------------");
    }
}

