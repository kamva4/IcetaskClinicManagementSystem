
package com.mycompany.clinicmanagementsystem;

public class GeneralPatient extends Patient {
    private String preferredDoctor;
    private String insuranceProvider;

    public GeneralPatient(String patientId, String firstName, String lastName, String dateOfBirth,
                          String contactNumber, String email, String medicalHistory,
                          String preferredDoctor, String insuranceProvider) {
        super(patientId, firstName, lastName, dateOfBirth, contactNumber, email, medicalHistory, PatientType.GENERAL);
        this.preferredDoctor = preferredDoctor;
        this.insuranceProvider = insuranceProvider;
    }
    public String getPreferredDoctor() { return preferredDoctor; }
    public String getInsuranceProvider() { return insuranceProvider; }
    public void setPreferredDoctor(String v){this.preferredDoctor=v;}
    public void setInsuranceProvider(String v){this.insuranceProvider=v;}

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("Preferred Doctor: " + preferredDoctor);
        System.out.println("Insurance: " + insuranceProvider);
        System.out.println("-----------------------------------");
    }
}

    

