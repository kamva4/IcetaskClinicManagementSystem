package com.mycompany.clinicmanagementsystem;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ClinicManagementSystemTest {
    ClinicManagementSystem cms;
    
    @BeforeEach void setUp(){ 
        cms = new ClinicManagementSystem(); 
    }

    @Test void testRegisterPatient(){ 
        Patient p=new Patient("P001","John","Doe","01/01/1990","0123456789","john@test.com","None",PatientType.GENERAL){}; 
        assertTrue(cms.addPatient(p)); 
    }
    
    @Test void testSearchPatient(){ 
        cms.addPatient(new Patient("P002","Jane","Doe","02/02/1990","0123456789","j@test.com","None",PatientType.GENERAL){}); 
        assertNotNull(cms.searchPatient("P002")); 
    }
    
    @Test void testDuplicatePatientId(){ 
        cms.addPatient(new Patient("P007","A","A","01/01/1990","0123456789","a@test.com","None",PatientType.GENERAL){}); 
        assertFalse(cms.addPatient(new Patient("P007","B","B","01/01/1990","0123456789","b@test.com","None",PatientType.GENERAL){})); 
    }
    
    @Test void testScheduleAppointment(){ 
        cms.addPatient(new GeneralPatient("P005","Sam","Sam","01/01/1990","0123456789","s@test.com","None","Dr","Ins")); 
        assertTrue(cms.scheduleAppointment("Monday 9:00 AM","P005")); 
    }
    
    @Test void testDoubleBooking(){ 
        cms.addPatient(new GeneralPatient("P008","A","A","01/01/1990","0123456789","a@test.com","None","Dr","I")); 
        cms.addPatient(new GeneralPatient("P009","B","B","01/01/1990","0123456789","b@test.com","None","Dr","I")); 
        assertTrue(cms.scheduleAppointment("Tuesday 9:00 AM","P008")); 
        assertFalse(cms.scheduleAppointment("Tuesday 9:00 AM","P009")); 
    }
    
    @Test void testAllSlotsBooked(){ 
        for(int i=0;i<15;i++){ 
            String pid=String.format("P%03d",i+10); 
            cms.addPatient(new GeneralPatient(pid,"N"+i,"S"+i,"01/01/1990","0123456789","t"+i+"@t.com","None","Dr","I")); 
            cms.scheduleAppointment(cms.getAppointments().get(i).getTimeSlot(),pid); 
        } 
        Patient ex=new GeneralPatient("P999","Ex","Ex","01/01/1990","0123456789","ex@test.com","None","Dr","I"); 
        cms.addPatient(ex); 
        assertFalse(cms.scheduleAppointment("Monday 9:00 AM","P999")); 
    }
    
    @Test void testSortByLastName(){ 
        cms.addPatient(new Patient("P010","John","Zebra","01/01/1990","0123456789","z@test.com","None",PatientType.GENERAL){}); 
        cms.addPatient(new Patient("P011","John","Apple","01/01/1990","0123456789","a@test.com","None",PatientType.GENERAL){}); 
        assertEquals("Apple",cms.sortBySurname().get(0).getLastName()); 
    }
    
    @Test void testSortById(){ 
        cms.addPatient(new Patient("P020","A","A","01/01/1990","0123456789","a@test.com","None",PatientType.GENERAL){}); 
        cms.addPatient(new Patient("P001","B","B","01/01/1990","0123456789","b@test.com","None",PatientType.GENERAL){}); 
        assertEquals("P001",cms.sortByPatientId().get(0).getPatientId()); 
    }
}